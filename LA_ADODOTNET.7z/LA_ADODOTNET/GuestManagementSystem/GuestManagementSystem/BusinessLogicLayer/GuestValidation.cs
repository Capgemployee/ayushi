﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Data;
using Entity;
using CustomException;
using DataAccessLayer;



namespace BusinessLogicLayer
{
    public class GuestValidation
    {
        GuestOperation operationObj = new GuestOperation();

        public bool ValidateGuest(Guest guestObj)
        {
            bool validGuest = true;
            StringBuilder sb = new StringBuilder();
            if (guestObj.GuestID.ToString().Length == 0)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Guest ID is required.");
            }
            if (guestObj.GuestName.Length == 0)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Guest Name is required.");
            }
            if (guestObj.ContactNo.ToString().Length == 0)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Guest Contact No is required.");
            }
            if (!(Regex.IsMatch(guestObj.GuestID.ToString(), @"^[0-9]+$")))
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Guest ID should contain only numbers.");
            }
            if (!(Regex.IsMatch(guestObj.GuestName, @"^[a-zA-Z ]+$")))
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Employee Name should contain only characters.");
            }
            if (!(Regex.IsMatch(guestObj.ContactNo.ToString(), @"^[0-9]+$")))
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Contact number should contain only numbers.");
            }
            if (guestObj.ContactNo.ToString().Length != 10)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Conatct No should consist of 10 digits only.");
            }
            if (validGuest == false)
                throw new GuestException(sb.ToString());
            return validGuest;
        }

        //Method to add
        public bool AddGuestRecord(Guest guestObj)
        {
            bool guestAdded = false;
            if (ValidateGuest(guestObj))
                guestAdded = operationObj.AddGuestRecord(guestObj);
            return guestAdded;
        }

        //method to search
        public DataTable GetGuestRecord(int guestID)
        {
            Guest guestObj = null;

            DataTable guestTable = operationObj.GetGuestRecord(guestID);
            return guestTable;

        }

        //method to display all guest details
        public DataTable DisplayGuestRecord()
        {
            DataTable guestTable = operationObj.DisplayGuestRecord();
            return guestTable;
        }

        //method to update
        public bool UpdateGuestRecord(Guest guestObj)
        {
            bool guestUpdated = false;

            try
            {
                if (ValidateGuest(guestObj))
                    guestUpdated = operationObj.UpdateGuestRecord(guestObj);
                return guestUpdated;
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return guestUpdated;
        }

        //method to delete
        public bool DeleteGuestRecord(int guestID)
        {
            bool guestDeleted = false;

            try
            {
                guestDeleted = operationObj.DeleteGuestRecord(guestID);
                return guestDeleted;
               
            }
            catch (GuestException ex)
            {
                throw ex;
            }
          
            catch (SystemException ex)
            {
                throw ex;
            }

            return guestDeleted;
        }

    }
}
