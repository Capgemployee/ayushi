﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomException
{
    public class GuestException:ApplicationException
    {
        public GuestException() : base() { }
        public GuestException(string message) : base(message) { }
    }
}
