﻿using System;
using System.Collections.Generic;
using System.Web;

/// <summary>
/// Summary description for Operation
/// </summary>
public class Operation
{
	public Operation()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public void calculateresult(Student stud, out int total, out double perc)
    {
        total = stud.Marks1 + stud.Marks2 + stud.Marks3 + stud.Marks4 + stud.Marks5;
        perc = total / 5;
    }
}