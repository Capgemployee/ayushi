﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Student st = new Student();
            st.Name = TextBox9.Text;
            st.Age = Convert.ToInt32(TextBox8.Text);
            st.Marks1 = Convert.ToInt32(TextBox7.Text);
            st.Marks2 = Convert.ToInt32(TextBox6.Text);
            st.Marks3 = Convert.ToInt32(TextBox5.Text);
            st.Marks4 = Convert.ToInt32(TextBox4.Text);
            st.Marks5 = Convert.ToInt32(TextBox3.Text);
            int total;
            double perc;
            Operation o = new Operation();
            o.calculateresult(st, out total, out perc);
            TextBox2.Text = total.ToString();
            TextBox1.Text = perc.ToString();
        }
    }
}