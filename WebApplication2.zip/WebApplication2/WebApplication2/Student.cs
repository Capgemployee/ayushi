﻿using System;
using System.Collections.Generic;
using System.Web;

/// <summary>
/// Summary description for Student
/// </summary>
public  class Student
{  
    public string Name { get; set; }
    public int Age { get; set; }
    public int Marks1 { get; set; }
    public int Marks2 { get; set; }
    public int Marks3 { get; set; }
    public int Marks4 { get; set; }
    public int Marks5 { get; set; }
}