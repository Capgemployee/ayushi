﻿using System;
using System.Collections.Generic;
using System.Web;

namespace WebApplication3
{
    public class Student
    {
    }
}